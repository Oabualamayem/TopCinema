Top Cinema - مشروع Android

هذا مشروع Android Studio جاهز كمصدر لبناء تطبيق APK، وليس ملف APK مبنياً.
لم أتمكن من إنتاج APK مباشرة لأن بيئة التنفيذ الحالية لا تحتوي على Android SDK أو Gradle.

طريقة البناء:
1) فك ضغط الملف.
2) افتح مجلد TopCinemaAndroid من Android Studio.
3) انتظر مزامنة Gradle وتنزيل Android SDK المطلوبة.
4) من القائمة Build اختر Build Bundle(s) / APK(s) ثم Build APK(s).
5) ستجد الملف غالباً في app/build/outputs/apk/debug/app-debug.apk.

التطبيق يفتح https://topcinemaa.one داخل WebView، ويمنع النوافذ المنبثقة ويحجب مجموعة من نطاقات الإعلانات الشائعة.
تنبيه: لا يمكن ضمان إزالة كل الإعلانات؛ إذا كانت الإعلانات تُحمّل من نفس نطاق الموقع أو تغيّرت آلية الموقع فقد تظهر بعض الإعلانات.
المشروع لا يضيف أي شبكة إعلانية أو SDK إعلاني.
