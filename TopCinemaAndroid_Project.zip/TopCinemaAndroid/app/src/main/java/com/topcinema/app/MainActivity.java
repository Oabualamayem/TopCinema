package com.topcinema.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebChromeClient;
import android.graphics.Color;
import android.os.Build;
import java.io.ByteArrayInputStream;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private static final String HOME = "https://topcinemaa.one/";

    // Basic domain-level filtering. This is not a complete ad-blocking engine.
    private static final String[] BLOCKED = {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "adnxs.com", "adform.net", "taboola.com",
        "outbrain.com", "popads.net", "popcash.net", "propellerads.com",
        "exoclick.com", "trafficjunky.net", "adsterra.com", "onclick.com",
        "clickadu.com", "mgid.com"
    };

    private boolean isBlocked(String url) {
        String u = url == null ? "" : url.toLowerCase(Locale.ROOT);
        for (String domain : BLOCKED) if (u.contains(domain)) return true;
        return false;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(9,9,9));
        getWindow().setNavigationBarColor(Color.rgb(9,9,9));
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(9,9,9));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setLoadsImagesAutomatically(true);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onCreateWindow(WebView view, boolean dialog,
                    boolean userGesture, android.os.Message resultMsg) {
                return false; // Block pop-up windows.
            }
        });

        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                // Keep browsing inside the app; reject non-web schemes.
                return !(url.startsWith("https://") || url.startsWith("http://"));
            }

            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (isBlocked(request.getUrl().toString())) {
                    return new WebResourceResponse("text/plain", "UTF-8",
                            new ByteArrayInputStream(new byte[0]));
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                // Hide common ad containers and fixed overlays; site changes may require updates.
                String js = "(function(){"
                    + "var selectors=['iframe[src*=\"doubleclick\"]','iframe[src*=\"adservice\"]',"
                    + "'[id*=\"ad-\" i]','[class*=\"advert\" i]','[class*=\"popup\" i]',"
                    + "'[class*=\"popunder\" i]','[id*=\"popup\" i]'];"
                    + "selectors.forEach(function(q){try{document.querySelectorAll(q).forEach(function(e){e.remove();});}catch(x){}});"
                    + "})();";
                view.evaluateJavascript(js, null);
            }
        });

        if (state == null) webView.loadUrl(HOME);
        else webView.restoreState(state);
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (webView != null) webView.saveState(out);
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
